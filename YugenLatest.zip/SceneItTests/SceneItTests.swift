//
//  SceneItTests.swift
//  SceneItTests
//
//  Created by Alpha  Camara on 6/7/25.
//

import Testing

struct SceneItTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
